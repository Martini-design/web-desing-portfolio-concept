
// scroll to element on click

$(document).ready(function() {

    const scrollLink = $(".hoverLink");

    scrollLink.click(function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $(this.hash).offset().top
        }, 1000);
    });
});

// Rellax Js plugin
var rellax = new Rellax('.rellax');


// WOW Js Plugin
new WOW().init();


// GSAP Js animations

gsap.from(".menu-icon",1,{
    opacity: 0,
    y: -10,
    delay: 0.8,
    ease: Expo.easeInOut
});

gsap.from(".header h1", 2, {
    y: 100,
    delay: 1,
    opacity: 0,
    ease: Expo.easeInOut
});

gsap.from(".header p", 2, {
    y: 10,
    delay: 1.2,
    opacity: 0,
    ease: Expo.easeInOut
});

gsap.from(".headImg", 2, {
    y: 100,
    delay: 0.8,
    opacity: 0,
    ease: Power4.easeInOut
});

gsap.from(".logo", 1.2, {
    y: -6,
    delay: 1.2,
    opacity: 0,
    ease: Expo.easeInOut
});

gsap.from(".social-media ul li", 1.2, {
    x: -10,
    opacity: 0,
    delay: 1.4,
    stagger: 0.2,
    ease: Expo.easeInOut
});

gsap.from(".scrollDown", 1.2, {
    y: -10,
    delay: 1.6,
    opacity: 0,
    ease: Expo.easeInOut
});


// Menu
var tl = gsap.timeline({paused: true});

tl.to(".one", 0.5, {
    y: 5,
    rotation: 45,
    ease: Expo.easeInOut
});

tl.to(".two", 0.5, {
    y: -6,
    rotation: -45,
    ease: Expo.easeInOut,
    delay: -0.5
});

tl.to(".menu", 1, {
    top: "0%",
    ease: Expo.easeInOut
});

tl.from(".menu ul li", 1, {
    x: -200,
    opacity: 0,
    ease: Expo.easeOut,
    stagger: 0.2
});

tl.reverse();
$(document).on("click", ".menu-icon", function() {
    tl.reversed(!tl.reversed());
});

$(document).on("click", ".menu a", function() {
    tl.reversed(!tl.reversed());
});

